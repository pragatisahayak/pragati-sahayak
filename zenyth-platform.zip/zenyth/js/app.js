/* ════════════════════════════════════════════════════════
   ZENYTH — app.js
   SPA Router + Page Renderers
   Pages: home · products · product-detail · cart
          checkout · login/signup
   ════════════════════════════════════════════════════════ */

'use strict';

/* ─── App Router ─────────────────────────────────────── */
const App = (() => {

  const appEl = document.getElementById('app');
  let currentPage = null;

  /**
   * Navigate to a page.
   * @param {string} page   - 'home' | 'products' | 'detail' | 'cart' | 'checkout' | 'login'
   * @param {Object} params - additional params (category, productId, search…)
   */
  function navigate(page, params = {}) {
    if (!appEl) return;
    currentPage = page;

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Show loading spinner briefly
    appEl.innerHTML = `<div class="page-loading"><div class="pl-spinner"></div></div>`;

    setTimeout(() => {
      let html = '';
      switch (page) {
        case 'home':     html = renderHome();            break;
        case 'products': html = renderProducts(params);  break;
        case 'detail':   html = renderDetail(params);    break;
        case 'cart':     html = renderCart();             break;
        case 'checkout': html = renderCheckout();         break;
        case 'login':    html = renderAuth();             break;
        default:         html = renderHome();
      }

      appEl.innerHTML = `<div class="page-enter">${html}</div>`;

      // Post-render init
      _initPageEvents(page, params);
      Reveal.observe();
      Countdown.stop();
      if (page === 'home') _initHomeEvents();
    }, 180);
  }

  /* ════════════════════════════════════════
     HOME PAGE
  ════════════════════════════════════════ */
  function renderHome() {
    const featured  = getFeaturedProducts().slice(0, 8);
    const flashSale = getFlashSaleProducts().slice(0, 4);
    const newArrivals = getNewArrivals().slice(0, 4);

    // Flash sale ends in 6 hours from now
    const saleEnd = new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString();

    return `
    <!-- ── HERO ── -->
    <section class="hero-section">
      <div class="hero-bg"></div>
      <div class="hero-grid"></div>
      <div class="hero-container">

        <div class="hero-label anim-fade-up">
          <span class="hero-label-dot"></span>
          New Season · Thousands of Deals Live Now
        </div>

        <h1 class="hero-title anim-fade-up anim-delay-1">
          Shop <span class="ht-violet">Smarter.</span><br/>
          Discover <span class="ht-coral">Faster.</span><br/>
          Live <em style="font-family:var(--font-display);font-style:italic">Better.</em>
        </h1>

        <p class="hero-sub anim-fade-up anim-delay-2">
          ZENYTH brings you the finest electronics, fashion, home essentials, and more — curated by experts, delivered to your door.
        </p>

        <!-- Hero Search -->
        <div class="hero-search anim-fade-up anim-delay-3" id="hero-search-wrap">
          <input class="hs-input" id="hero-search-input"
                 placeholder="Search for products, brands, deals…"
                 autocomplete="off" aria-label="Search products" />
          <div class="hs-divider" aria-hidden="true"></div>
          <select class="hs-category" id="hero-search-cat" aria-label="Category">
            <option value="all">All Categories</option>
            ${CATEGORIES.map(c => `<option value="${c.id}">${c.label}</option>`).join('')}
          </select>
          <button class="hs-btn" id="hero-search-btn" aria-label="Search">
            <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i> Search
          </button>
        </div>

        <div class="hero-trust anim-fade-up anim-delay-4">
          <div class="ht-item"><i class="fa-solid fa-truck-fast"></i> Free delivery on orders over ₹499</div>
          <div class="ht-item"><i class="fa-solid fa-shield-halved"></i> Secure payments</div>
          <div class="ht-item"><i class="fa-solid fa-arrow-rotate-left"></i> Easy 30-day returns</div>
          <div class="ht-item"><i class="fa-solid fa-headset"></i> 24/7 support</div>
        </div>

      </div>
    </section>

    <!-- ── CATEGORIES ── -->
    <div class="category-strip">
      <div class="cs-grid">
        ${CATEGORIES.map(c => `
          <div class="cs-item reveal" data-page="products" data-cat="${c.id}">
            <div class="cs-icon">${c.icon}</div>
            <div class="cs-label">${c.label}</div>
          </div>`).join('')}
        <div class="cs-item reveal" data-page="products" data-cat="all">
          <div class="cs-icon">🛍️</div>
          <div class="cs-label">All Items</div>
        </div>
      </div>
    </div>

    <!-- ── PROMO BANNERS ── -->
    <div class="promo-banner-strip">
      <div class="container">
        <div class="promo-banner pb-1 reveal" data-page="products" data-cat="electronics">
          <span class="pb-tag">Electronics</span>
          <p class="pb-title">Tech at Your Fingertips</p>
          <p class="pb-desc">Up to 44% off on top gadgets & accessories</p>
          <div class="pb-cta">Shop Now <i class="fa-solid fa-arrow-right"></i></div>
          <div class="pb-icon">📱</div>
        </div>
        <div class="promo-banner pb-2 reveal" data-delay="100" data-page="products" data-cat="fashion">
          <span class="pb-tag">Fashion</span>
          <p class="pb-title">Style That Speaks</p>
          <p class="pb-desc">Trendsetting looks for every occasion</p>
          <div class="pb-cta">Discover <i class="fa-solid fa-arrow-right"></i></div>
          <div class="pb-icon">👗</div>
        </div>
        <div class="promo-banner pb-3 reveal" data-delay="200" data-page="products" data-cat="home">
          <span class="pb-tag">Home & Living</span>
          <p class="pb-title">Your Dream Space</p>
          <p class="pb-desc">Transform your home with curated decor</p>
          <div class="pb-cta">Explore <i class="fa-solid fa-arrow-right"></i></div>
          <div class="pb-icon">🏡</div>
        </div>
      </div>
    </div>

    <!-- ── FEATURED PRODUCTS ── -->
    <section class="products-section">
      <div class="container">
        <div class="section-header reveal">
          <div class="sh-left">
            <span class="sh-label">Handpicked For You</span>
            <h2 class="sh-title">Featured Products</h2>
          </div>
          <a href="#" class="sh-see-all" data-page="products" data-cat="all">
            View All <i class="fa-solid fa-arrow-right"></i>
          </a>
        </div>
        <div class="products-grid">
          ${featured.map((p, i) => renderProductCard(p, i * 80)).join('')}
        </div>
      </div>
    </section>

    <!-- ── FLASH SALE ── -->
    <section class="flash-sale-section">
      <div class="container">
        <div class="fs-banner">
          <div style="position:relative;z-index:2;flex:1">
            <div class="fs-badge"><i class="fa-solid fa-bolt"></i> Flash Sale</div>
            <h2 class="fs-title">Lightning Deals — Don't Miss Out</h2>
            <p class="fs-desc">Prices drop. Stock disappears. Grab yours now.</p>
            <div class="countdown" id="home-countdown" role="timer" aria-label="Sale ends in">
              <div class="cd-unit">
                <span class="cd-num" data-cd="hours">06</span>
                <span class="cd-label">Hours</span>
              </div>
              <span class="cd-sep" aria-hidden="true">:</span>
              <div class="cd-unit">
                <span class="cd-num" data-cd="minutes">00</span>
                <span class="cd-label">Mins</span>
              </div>
              <span class="cd-sep" aria-hidden="true">:</span>
              <div class="cd-unit">
                <span class="cd-num" data-cd="seconds">00</span>
                <span class="cd-label">Secs</span>
              </div>
            </div>
            <button class="btn btn-secondary btn-lg" data-page="products" data-cat="all">
              <i class="fa-solid fa-bolt"></i> Shop Flash Deals
            </button>
          </div>
          <div class="fs-right">
            <div class="products-grid" style="grid-template-columns:repeat(2,1fr);max-width:520px">
              ${flashSale.map((p, i) => renderProductCard(p, i * 100)).join('')}
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ── NEW ARRIVALS ── -->
    <section class="products-section">
      <div class="container">
        <div class="section-header reveal">
          <div class="sh-left">
            <span class="sh-label">Just Landed</span>
            <h2 class="sh-title">New Arrivals</h2>
          </div>
          <a href="#" class="sh-see-all" data-page="products" data-cat="all">
            See All <i class="fa-solid fa-arrow-right"></i>
          </a>
        </div>
        <div class="products-grid">
          ${newArrivals.length
            ? newArrivals.map((p, i) => renderProductCard(p, i * 80)).join('')
            : getAllProducts().slice(0, 4).map((p, i) => renderProductCard(p, i * 80)).join('')}
        </div>
      </div>
    </section>

    <!-- ── TRUST STRIP ── -->
    <section style="padding:48px 0;background:var(--bg-raised);border-top:1px solid var(--border);border-bottom:1px solid var(--border)">
      <div class="container">
        <div class="grid-4" style="text-align:center;gap:32px">
          ${[
            { icon: 'fa-truck-fast',       color: '#7C3AED', title: 'Free Delivery',     desc: 'On all orders above ₹499' },
            { icon: 'fa-shield-halved',     color: '#10B981', title: 'Secure Payments',   desc: '256-bit SSL encryption' },
            { icon: 'fa-arrow-rotate-left', color: '#F59E0B', title: '30-Day Returns',    desc: 'No questions asked' },
            { icon: 'fa-headset',           color: '#EC4899', title: '24/7 Support',      desc: 'Live chat & phone support' },
          ].map(t => `
            <div class="reveal" style="display:flex;flex-direction:column;align-items:center;gap:12px">
              <div style="width:56px;height:56px;border-radius:var(--radius-md);background:rgba(124,58,237,0.1);
                          display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:${t.color}">
                <i class="fa-solid ${t.icon}"></i>
              </div>
              <strong style="font-family:var(--font-display);font-size:0.95rem">${t.title}</strong>
              <span style="font-size:0.82rem;color:var(--text-3)">${t.desc}</span>
            </div>`).join('')}
        </div>
      </div>
    </section>`;
  }

  /* ════════════════════════════════════════
     PRODUCTS LIST PAGE
  ════════════════════════════════════════ */
  function renderProducts(params = {}) {
    const cat    = params.category || 'all';
    const search = params.search   || '';
    const sort   = params.sort     || 'popular';

    let list = search
      ? searchProducts(search)
      : getProductsByCategory(cat, sort);

    if (search) list = sortProducts(list, sort);

    const catObj = CATEGORIES.find(c => c.id === cat);
    const pageTitle = search
      ? `Results for "${search}"`
      : (catObj ? catObj.label : 'All Products');

    const brands  = getBrandsForCategory(cat);
    const maxPrice = Math.max(...list.map(p => p.price), 100000);

    return `
    <div class="products-page">
      <div class="container">

        <!-- Breadcrumb -->
        <nav class="breadcrumb" aria-label="Breadcrumb">
          <a href="#" data-page="home">Home</a>
          <span class="sep" aria-hidden="true">›</span>
          <span class="current">${pageTitle}</span>
        </nav>

        <!-- Mobile filter toggle -->
        <button class="filter-toggle-btn" id="filter-toggle-btn">
          <i class="fa-solid fa-sliders"></i> Filters
        </button>

        <div class="products-page-layout">

          <!-- ── Sidebar Filters ── -->
          <aside class="filter-sidebar" id="filter-sidebar" aria-label="Product filters">
            <div class="fs-title">
              Filters
              <button class="fs-clear-btn" id="clear-filters-btn">Clear all</button>
            </div>

            <!-- Category -->
            <div class="filter-group">
              <div class="filter-group-title" tabindex="0" role="button">
                Category <i class="fa-solid fa-chevron-down"></i>
              </div>
              <div class="filter-options">
                ${CATEGORIES.map(c => `
                  <label class="filter-option">
                    <input type="radio" name="filter-cat" value="${c.id}" ${cat === c.id ? 'checked' : ''} />
                    ${c.icon} ${c.label}
                    <span class="fo-count">${PRODUCTS.filter(p => p.category === c.id).length}</span>
                  </label>`).join('')}
                <label class="filter-option">
                  <input type="radio" name="filter-cat" value="all" ${cat === 'all' ? 'checked' : ''} />
                  🛍️ All Products
                  <span class="fo-count">${PRODUCTS.length}</span>
                </label>
              </div>
            </div>

            <!-- Price Range -->
            <div class="filter-group">
              <div class="filter-group-title" tabindex="0" role="button">
                Price Range <i class="fa-solid fa-chevron-down"></i>
              </div>
              <div class="price-range-wrap">
                <input type="range" class="price-range-input" id="price-range"
                       min="0" max="${maxPrice}" value="${maxPrice}" step="100"
                       aria-label="Maximum price" />
                <div class="price-labels">
                  <span>₹0</span>
                  <span id="price-range-val">₹${maxPrice.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>

            <!-- Rating -->
            <div class="filter-group">
              <div class="filter-group-title" tabindex="0" role="button">
                Minimum Rating <i class="fa-solid fa-chevron-down"></i>
              </div>
              <div class="star-filter-options">
                ${[4,3,2,1].map(r => `
                  <button class="star-filter-btn" data-min-rating="${r}">
                    <span class="stars">${'★'.repeat(r)}${'☆'.repeat(5-r)}</span>
                    ${r}+ Stars
                  </button>`).join('')}
              </div>
            </div>

            <!-- Brand -->
            <div class="filter-group">
              <div class="filter-group-title" tabindex="0" role="button">
                Brand <i class="fa-solid fa-chevron-down"></i>
              </div>
              <div class="filter-options" id="brand-filters">
                ${brands.slice(0,8).map(b => `
                  <label class="filter-option">
                    <input type="checkbox" name="brand" value="${b}" />
                    ${b}
                  </label>`).join('')}
              </div>
            </div>

            <!-- Availability -->
            <div class="filter-group">
              <div class="filter-group-title" tabindex="0" role="button">
                Availability <i class="fa-solid fa-chevron-down"></i>
              </div>
              <div class="filter-options">
                <label class="filter-option">
                  <input type="checkbox" id="filter-instock" /> In Stock Only
                </label>
                <label class="filter-option">
                  <input type="checkbox" id="filter-free-del" /> Free Delivery
                </label>
              </div>
            </div>

          </aside>

          <!-- ── Results ── -->
          <div class="pp-results">

            <!-- Sort Bar -->
            <div class="sort-bar">
              <div class="sort-bar-left">
                <strong id="results-count">${list.length}</strong> results
                ${search ? `for "<em>${search}</em>"` : `in ${pageTitle}`}
              </div>
              <div class="sort-bar-right">
                <span style="font-size:0.82rem;color:var(--text-3)">Sort:</span>
                ${['popular','price-low','price-high','rating','discount','newest'].map(s => `
                  <button class="sort-btn ${s === sort ? 'active' : ''}" data-sort="${s}">
                    ${{ popular:'Popular', 'price-low':'Price ↑', 'price-high':'Price ↓',
                        rating:'Rating', discount:'Discount', newest:'Newest' }[s]}
                  </button>`).join('')}
                <div class="view-toggle" role="group" aria-label="View layout">
                  <button class="view-btn active" data-view="grid" aria-label="Grid view">
                    <i class="fa-solid fa-grip"></i>
                  </button>
                  <button class="view-btn" data-view="list" aria-label="List view">
                    <i class="fa-solid fa-list"></i>
                  </button>
                </div>
              </div>
            </div>

            <!-- Grid -->
            <div class="products-grid" id="products-grid">
              ${list.length
                ? list.map((p, i) => renderProductCard(p, i * 60)).join('')
                : `<div class="empty-state" style="grid-column:1/-1">
                    <div class="es-icon">🔍</div>
                    <h3 class="es-title">No products found</h3>
                    <p class="es-desc">Try different keywords or browse our categories.</p>
                    <button class="btn btn-primary" data-page="home" style="margin-top:8px">Back to Home</button>
                  </div>`}
            </div>

          </div>
        </div>
      </div>
    </div>`;
  }

  /* ════════════════════════════════════════
     PRODUCT DETAIL PAGE
  ════════════════════════════════════════ */
  function renderDetail(params = {}) {
    const p = getProductById(params.productId);
    if (!p) return `<div class="container" style="padding:80px 0;text-align:center">
      <h2>Product not found</h2>
      <button class="btn btn-primary" data-page="home" style="margin-top:20px">Back to Home</button>
    </div>`;

    const wishlisted = Cart.isWishlisted(p.id);
    const related    = PRODUCTS.filter(r => r.category === p.category && r.id !== p.id).slice(0, 4);

    return `
    <div class="product-detail">
      <div class="container">

        <!-- Breadcrumb -->
        <nav class="breadcrumb" aria-label="Breadcrumb">
          <a href="#" data-page="home">Home</a>
          <span class="sep">›</span>
          <a href="#" data-page="products" data-cat="${p.category}">${CATEGORIES.find(c=>c.id===p.category)?.label||p.category}</a>
          <span class="sep">›</span>
          <span class="current" style="max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            ${p.name.slice(0, 50)}${p.name.length > 50 ? '…' : ''}
          </span>
        </nav>

        <div class="pd-layout">

          <!-- ── Gallery ── -->
          <div class="pd-gallery">
            <div class="pd-main-img" id="pd-main-img">
              <img src="${p.images[0]}" alt="${p.name}" id="pd-main-img-el" loading="eager" />
            </div>
            ${p.images.length > 1 ? `
              <div class="pd-thumbs" id="pd-thumbs" role="list" aria-label="Product images">
                ${p.images.map((img, i) => `
                  <div class="pd-thumb ${i === 0 ? 'active' : ''}" data-img="${img}" data-idx="${i}" role="listitem">
                    <img src="${img}" alt="Product image ${i+1}" loading="lazy" />
                  </div>`).join('')}
              </div>` : ''}
          </div>

          <!-- ── Info ── -->
          <div class="pd-info">
            <div class="pd-brand">${p.brand}</div>
            <h1 class="pd-title">${p.name}</h1>

            <!-- Rating -->
            <div class="pd-rating-row">
              <div class="pd-rating-score">${p.rating}</div>
              <div class="stars-display" aria-label="${p.rating} out of 5 stars">
                ${renderStars(p.rating)}
              </div>
              <span class="pd-review-count">(${p.ratingCount.toLocaleString('en-IN')} ratings)</span>
              <span class="pd-sold">${p.soldCount.toLocaleString('en-IN')}+ sold</span>
            </div>

            <!-- Badges -->
            ${p.badge ? `<div style="margin-bottom:16px">
              <span class="badge badge-${p.badge.type}">${p.badge.text}</span>
            </div>` : ''}

            <!-- Price -->
            <div class="pd-price-row">
              <div class="pd-price">${formatPrice(p.price)}</div>
              ${p.originalPrice ? `<div class="pd-original-price">${formatPrice(p.originalPrice)}</div>` : ''}
              ${p.discount ? `<div class="pd-discount-badge">${p.discount}% off</div>` : ''}
            </div>
            ${p.emi ? `<div class="pd-emi">EMI from <strong>${p.emi}</strong> · No cost EMI available</div>` : ''}

            <div class="divider"></div>

            <!-- Variants -->
            ${p.variants && Object.keys(p.variants).length ? `
              <div class="pd-variants">
                ${Object.entries(p.variants).map(([key, options]) => `
                  <div style="margin-bottom:16px">
                    <div class="pv-label">${key.charAt(0).toUpperCase() + key.slice(1)}</div>
                    <div class="pv-options">
                      ${options.map((opt, i) =>
                        key === 'color'
                          ? `<button class="pv-color ${i===0?'active':''}" data-variant-key="${key}" data-variant-val="${opt}"
                                     style="background:${_colorMap(opt)}" title="${opt}" aria-label="${opt}"></button>`
                          : `<button class="pv-btn ${i===0?'active':''}" data-variant-key="${key}" data-variant-val="${opt}">${opt}</button>`
                      ).join('')}
                    </div>
                  </div>`).join('')}
              </div>` : ''}

            <!-- Quantity -->
            <div style="display:flex;align-items:center;gap:16px;margin-bottom:20px">
              <span style="font-size:0.85rem;font-weight:600;color:var(--text-2)">Quantity</span>
              <div class="qty-selector" id="qty-selector" role="group" aria-label="Quantity">
                <button class="qty-btn" id="qty-dec" aria-label="Decrease">−</button>
                <input class="qty-value" id="qty-value" value="1" readonly aria-label="Quantity" />
                <button class="qty-btn" id="qty-inc" aria-label="Increase">+</button>
              </div>
              <span style="font-size:0.82rem;color:${p.inStock ? '#34D399' : '#EF4444'};font-weight:600">
                <i class="fa-solid ${p.inStock ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                ${p.inStock ? 'In Stock' : 'Out of Stock'}
              </span>
            </div>

            <!-- Actions -->
            <div class="pd-actions">
              <div class="pd-actions-row">
                <button class="btn btn-primary btn-lg" id="pd-add-cart" style="flex:1"
                        ${!p.inStock ? 'disabled' : ''} data-product-id="${p.id}">
                  <i class="fa-solid fa-bag-shopping"></i> Add to Cart
                </button>
                <button class="btn btn-icon btn-lg ${wishlisted ? 'active' : ''}"
                        id="pd-wishlist" aria-label="Add to wishlist" data-product-id="${p.id}"
                        style="width:52px;height:52px;border:1.5px solid var(--border);color:${wishlisted?'#EF4444':'var(--text-3)'}">
                  <i class="fa-${wishlisted?'solid':'regular'} fa-heart"></i>
                </button>
              </div>
              <button class="btn btn-secondary btn-lg btn-full" id="pd-buy-now"
                      ${!p.inStock ? 'disabled' : ''} data-product-id="${p.id}">
                <i class="fa-solid fa-bolt"></i> Buy Now
              </button>
            </div>

            <!-- Delivery info -->
            <div class="pd-delivery-box">
              <div class="pdb-row">
                <i class="fa-solid fa-truck-fast"></i>
                <span><strong>${p.freeDelivery ? 'Free Delivery' : `₹${99} Delivery`}</strong> — arrives in ${p.deliveryDays} day${p.deliveryDays>1?'s':''}</span>
              </div>
              <div class="pdb-row">
                <i class="fa-solid fa-arrow-rotate-left"></i>
                <span><strong>30-Day Returns</strong> — hassle-free return policy</span>
              </div>
              <div class="pdb-row">
                <i class="fa-solid fa-shield-halved"></i>
                <span><strong>Secure Payment</strong> — 256-bit SSL encryption</span>
              </div>
            </div>

            <!-- Highlights -->
            ${p.highlights?.length ? `
              <div class="pd-features">
                <div style="font-size:0.85rem;font-weight:700;color:var(--text-2);margin-bottom:10px">HIGHLIGHTS</div>
                ${p.highlights.map(h => `
                  <div class="pdf-item">
                    <i class="fa-solid fa-check"></i> ${h}
                  </div>`).join('')}
              </div>` : ''}

          </div>
        </div>

        <!-- ── Description & Reviews Tabs ── -->
        <div style="margin-top:48px">
          <div class="tabs" id="detail-tabs" role="tablist">
            <button class="tab-btn active" data-tab="description" role="tab" aria-selected="true">Description</button>
            <button class="tab-btn" data-tab="reviews" role="tab" aria-selected="false">
              Reviews (${p.ratingCount.toLocaleString('en-IN')})
            </button>
            <button class="tab-btn" data-tab="specs" role="tab" aria-selected="false">Specifications</button>
          </div>

          <div id="tab-description" class="tab-panel active">
            <p style="color:var(--text-2);line-height:1.8;max-width:720px">${p.description}</p>
          </div>

          <div id="tab-reviews" class="tab-panel">
            ${_renderReviews(p)}
          </div>

          <div id="tab-specs" class="tab-panel">
            ${_renderSpecs(p)}
          </div>
        </div>

        <!-- ── Related Products ── -->
        ${related.length ? `
          <div style="margin-top:60px">
            <div class="section-header">
              <div class="sh-left">
                <span class="sh-label">More Like This</span>
                <h2 class="sh-title">Related Products</h2>
              </div>
            </div>
            <div class="products-grid">
              ${related.map((r, i) => renderProductCard(r, i * 80)).join('')}
            </div>
          </div>` : ''}

      </div>
    </div>`;
  }

  /* ════════════════════════════════════════
     CART PAGE
  ════════════════════════════════════════ */
  function renderCart() {
    const { items, subtotal, savings, delivery, total } = Cart.getCartData();

    if (items.length === 0) {
      return `
        <div class="cart-page">
          <div class="container">
            <h1 class="font-display" style="font-size:1.8rem;font-weight:700;margin-bottom:32px">Shopping Cart</h1>
            <div class="empty-cart">
              <div class="es-icon">🛍️</div>
              <h3 class="es-title">Your cart is empty</h3>
              <p class="es-desc">Looks like you haven't added anything yet. Let's fix that!</p>
              <button class="btn btn-primary btn-lg" data-page="home" style="margin-top:16px">
                Continue Shopping
              </button>
            </div>
          </div>
        </div>`;
    }

    return `
    <div class="cart-page">
      <div class="container">
        <h1 class="font-display" style="font-size:1.8rem;font-weight:700;margin-bottom:32px">
          Shopping Cart <span style="font-size:1rem;font-weight:400;color:var(--text-3)">(${items.length} item${items.length>1?'s':''})</span>
        </h1>

        <div class="cart-page-layout">

          <!-- ── Cart Items ── -->
          <div>
            <div class="cart-items-list" id="cart-items-list">
              ${items.map(item => renderCartItem(item)).join('')}
            </div>

            <!-- Continue shopping -->
            <div style="margin-top:20px">
              <button class="btn btn-outline" data-page="home">
                <i class="fa-solid fa-arrow-left"></i> Continue Shopping
              </button>
            </div>
          </div>

          <!-- ── Order Summary ── -->
          <div class="order-summary">
            <div class="os-title">Order Summary</div>

            <div class="os-row">
              <span>Subtotal (${items.reduce((s,i)=>s+i.qty,0)} items)</span>
              <span>${formatPrice(subtotal)}</span>
            </div>
            ${savings > 0 ? `
              <div class="os-row"><span>You Save</span>
                <span class="os-savings">−${formatPrice(savings)}</span>
              </div>` : ''}
            <div class="os-row">
              <span>Delivery</span>
              <span>${delivery === 0 ? '<span style="color:#34D399">FREE</span>' : formatPrice(delivery)}</span>
            </div>

            <!-- Coupon -->
            <div class="os-coupon">
              <input type="text" class="form-input" id="coupon-input" placeholder="Coupon code" aria-label="Coupon code" />
              <button class="btn btn-outline" id="coupon-apply-btn">Apply</button>
            </div>
            <div id="coupon-msg" style="font-size:0.8rem;margin-top:-8px;margin-bottom:8px"></div>

            <div class="os-row total">
              <span>Total</span>
              <span id="order-total">${formatPrice(total)}</span>
            </div>

            <button class="btn btn-primary btn-full btn-lg" id="checkout-btn" style="margin-top:16px">
              <i class="fa-solid fa-lock"></i> Proceed to Checkout
            </button>

            <div class="os-trust">
              <div class="os-trust-item"><i class="fa-solid fa-shield-halved"></i> SSL Secured Checkout</div>
              <div class="os-trust-item"><i class="fa-brands fa-cc-visa"></i> Visa, Mastercard, UPI, NetBanking</div>
              <div class="os-trust-item"><i class="fa-solid fa-arrow-rotate-left"></i> Free 30-day returns</div>
            </div>
          </div>

        </div>
      </div>
    </div>`;
  }

  /* ════════════════════════════════════════
     CHECKOUT PAGE
  ════════════════════════════════════════ */
  function renderCheckout() {
    const { items, subtotal, delivery, total, savings } = Cart.getCartData();

    return `
    <div class="checkout-page">
      <div class="container">
        <h1 class="font-display" style="font-size:1.8rem;font-weight:700;margin-bottom:24px">Checkout</h1>

        <!-- Steps -->
        <div class="checkout-steps">
          <div class="cs-step active"><div class="cs-step-num">1</div> Shipping</div>
          <div class="cs-step"><div class="cs-step-num">2</div> Payment</div>
          <div class="cs-step"><div class="cs-step-num">3</div> Review</div>
        </div>

        <div class="checkout-layout">

          <!-- ── Left Forms ── -->
          <div>

            <!-- Shipping -->
            <div class="checkout-card">
              <div class="cc-title"><i class="fa-solid fa-location-dot"></i> Delivery Address</div>
              <div class="grid-2">
                <div class="form-group">
                  <label class="form-label" for="ch-fname">First Name *</label>
                  <input class="form-input" id="ch-fname" type="text" placeholder="Priya" autocomplete="given-name" />
                </div>
                <div class="form-group">
                  <label class="form-label" for="ch-lname">Last Name *</label>
                  <input class="form-input" id="ch-lname" type="text" placeholder="Sharma" autocomplete="family-name" />
                </div>
              </div>
              <div class="form-group">
                <label class="form-label" for="ch-email">Email *</label>
                <input class="form-input" id="ch-email" type="email" placeholder="priya@email.com" autocomplete="email" />
              </div>
              <div class="form-group">
                <label class="form-label" for="ch-phone">Phone Number *</label>
                <input class="form-input" id="ch-phone" type="tel" placeholder="+91 98765 43210" autocomplete="tel" />
              </div>
              <div class="form-group">
                <label class="form-label" for="ch-addr">Address *</label>
                <input class="form-input" id="ch-addr" type="text" placeholder="Street address, apartment, suite…" autocomplete="street-address" />
              </div>
              <div class="grid-2">
                <div class="form-group">
                  <label class="form-label" for="ch-city">City *</label>
                  <input class="form-input" id="ch-city" type="text" placeholder="Mumbai" autocomplete="address-level2" />
                </div>
                <div class="form-group">
                  <label class="form-label" for="ch-pin">PIN Code *</label>
                  <input class="form-input" id="ch-pin" type="text" placeholder="400001" maxlength="6" autocomplete="postal-code" />
                </div>
              </div>
            </div>

            <!-- Payment -->
            <div class="checkout-card">
              <div class="cc-title"><i class="fa-solid fa-credit-card"></i> Payment Method</div>
              <div class="payment-methods" id="payment-methods" role="radiogroup" aria-label="Payment methods">
                ${[
                  { id:'upi',   icon:'fa-solid fa-qrcode',          label:'UPI Payment',    desc:'Google Pay, PhonePe, BHIM, Paytm' },
                  { id:'card',  icon:'fa-brands fa-cc-visa',         label:'Credit / Debit Card', desc:'Visa, Mastercard, RuPay' },
                  { id:'netb',  icon:'fa-solid fa-building-columns', label:'Net Banking',    desc:'All major banks' },
                  { id:'cod',   icon:'fa-solid fa-money-bill-wave',  label:'Cash on Delivery', desc:'Pay when your order arrives' },
                ].map((m, i) => `
                  <div class="pm-option ${i===0?'selected':''}" data-pm="${m.id}" role="radio" aria-checked="${i===0}" tabindex="0">
                    <div class="pm-radio"></div>
                    <i class="${m.icon} pm-icon"></i>
                    <div>
                      <div class="pm-label">${m.label}</div>
                      <div class="pm-desc">${m.desc}</div>
                    </div>
                  </div>`).join('')}
              </div>

              <!-- Card fields (shown when card selected) -->
              <div id="card-fields" style="margin-top:20px">
                <div class="form-group">
                  <label class="form-label">Card Number</label>
                  <div class="input-icon-wrap">
                    <i class="ii-icon fa-regular fa-credit-card"></i>
                    <input class="form-input" type="text" placeholder="1234 5678 9012 3456" maxlength="19" autocomplete="cc-number" />
                  </div>
                </div>
                <div class="grid-2">
                  <div class="form-group">
                    <label class="form-label">Expiry Date</label>
                    <input class="form-input" type="text" placeholder="MM / YY" maxlength="7" autocomplete="cc-exp" />
                  </div>
                  <div class="form-group">
                    <label class="form-label">CVV</label>
                    <div class="input-icon-wrap">
                      <input class="form-input" type="password" placeholder="•••" maxlength="4" autocomplete="cc-csc" />
                      <i class="ii-icon ii-right fa-solid fa-eye" title="Show CVV"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Place Order -->
            <button class="btn btn-primary btn-xl btn-full" id="place-order-btn">
              <i class="fa-solid fa-lock"></i> Place Order — ${formatPrice(total)}
            </button>
          </div>

          <!-- ── Order Summary ── -->
          <div>
            <div class="order-summary">
              <div class="os-title">Your Order</div>
              ${items.map(item => `
                <div style="display:flex;gap:12px;padding:12px 0;border-bottom:1px solid var(--border)">
                  <img src="${item.image}" alt="${item.name}" style="width:60px;height:60px;border-radius:var(--radius-sm);object-fit:cover;background:var(--surface-2)" loading="lazy" />
                  <div style="flex:1">
                    <div style="font-size:0.82rem;font-weight:500;line-height:1.4">${item.name.slice(0,50)}…</div>
                    <div style="font-size:0.78rem;color:var(--text-3);margin-top:4px">Qty: ${item.qty}</div>
                  </div>
                  <div style="font-size:0.875rem;font-weight:700;white-space:nowrap">${formatPrice(item.price * item.qty)}</div>
                </div>`).join('')}

              <div class="os-row" style="margin-top:12px"><span>Subtotal</span><span>${formatPrice(subtotal)}</span></div>
              ${savings > 0 ? `<div class="os-row"><span>Discount</span><span class="os-savings">−${formatPrice(savings)}</span></div>` : ''}
              <div class="os-row"><span>Delivery</span><span>${delivery === 0 ? '<span style="color:#34D399">FREE</span>' : formatPrice(delivery)}</span></div>
              <div class="os-row total"><span>Total</span><span>${formatPrice(total)}</span></div>
            </div>
          </div>

        </div>
      </div>
    </div>`;
  }

  /* ════════════════════════════════════════
     AUTH PAGE (Login / Sign Up)
  ════════════════════════════════════════ */
  function renderAuth() {
    return `
    <div class="auth-page">
      <div class="auth-container">
        <div class="auth-card">

          <div class="auth-logo">
            <div class="nav-logo" style="justify-content:center;font-size:2rem">
              <span class="logo-z">Z</span><span class="logo-rest">ENYTH</span>
            </div>
            <p style="font-size:0.85rem;color:var(--text-3);margin-top:8px">Your account. Your world.</p>
          </div>

          <!-- Tabs -->
          <div class="auth-tabs" role="tablist">
            <button class="auth-tab active" data-auth-tab="login" role="tab" aria-selected="true">Log In</button>
            <button class="auth-tab" data-auth-tab="signup" role="tab" aria-selected="false">Sign Up</button>
          </div>

          <!-- Social Login -->
          <div class="auth-social">
            <button class="auth-social-btn" id="google-login">
              <i class="fa-brands fa-google" style="color:#EA4335"></i> Continue with Google
            </button>
            <button class="auth-social-btn" id="apple-login">
              <i class="fa-brands fa-apple"></i> Continue with Apple
            </button>
          </div>

          <div class="divider-text">or continue with email</div>

          <!-- Login Form -->
          <form id="login-form" aria-label="Login form" novalidate>
            <div class="form-group">
              <label class="form-label" for="login-email">Email Address</label>
              <div class="input-icon-wrap">
                <i class="ii-icon fa-regular fa-envelope"></i>
                <input class="form-input" id="login-email" type="email"
                       placeholder="you@example.com" autocomplete="email" aria-required="true" />
              </div>
              <span class="form-error" id="login-email-err"></span>
            </div>
            <div class="form-group">
              <label class="form-label" for="login-password">
                Password
                <a href="#" style="float:right;font-size:0.8rem;color:var(--violet-light);font-weight:400">Forgot?</a>
              </label>
              <div class="input-icon-wrap">
                <i class="ii-icon fa-solid fa-lock"></i>
                <input class="form-input" id="login-password" type="password"
                       placeholder="••••••••" autocomplete="current-password" aria-required="true" />
                <i class="ii-icon ii-right fa-solid fa-eye" id="toggle-pw" title="Show password"></i>
              </div>
              <span class="form-error" id="login-pw-err"></span>
            </div>
            <label class="custom-check" style="margin-bottom:20px">
              <input type="checkbox" id="remember-me" />
              Remember me for 30 days
            </label>
            <button type="submit" class="btn btn-primary btn-full btn-lg" id="login-submit-btn">
              Log In to ZENYTH
            </button>
          </form>

          <!-- Sign Up Form (hidden by default) -->
          <form id="signup-form" style="display:none" aria-label="Sign up form" novalidate>
            <div class="grid-2">
              <div class="form-group">
                <label class="form-label" for="su-fname">First Name</label>
                <input class="form-input" id="su-fname" type="text" placeholder="Priya" autocomplete="given-name" />
                <span class="form-error" id="su-fname-err"></span>
              </div>
              <div class="form-group">
                <label class="form-label" for="su-lname">Last Name</label>
                <input class="form-input" id="su-lname" type="text" placeholder="Sharma" autocomplete="family-name" />
              </div>
            </div>
            <div class="form-group">
              <label class="form-label" for="su-email">Email Address</label>
              <div class="input-icon-wrap">
                <i class="ii-icon fa-regular fa-envelope"></i>
                <input class="form-input" id="su-email" type="email" placeholder="you@example.com" autocomplete="email" />
              </div>
              <span class="form-error" id="su-email-err"></span>
            </div>
            <div class="form-group">
              <label class="form-label" for="su-password">Password</label>
              <div class="input-icon-wrap">
                <i class="ii-icon fa-solid fa-lock"></i>
                <input class="form-input" id="su-password" type="password" placeholder="Min. 8 characters" autocomplete="new-password" />
              </div>
              <span class="form-error" id="su-pw-err"></span>
            </div>
            <label class="custom-check" style="margin-bottom:20px">
              <input type="checkbox" id="agree-terms" />
              I agree to the <a href="#" style="color:var(--violet-light)">Terms of Service</a> and
              <a href="#" style="color:var(--violet-light)">Privacy Policy</a>
            </label>
            <button type="submit" class="btn btn-primary btn-full btn-lg" id="signup-submit-btn">
              Create My Account
            </button>
          </form>

          <div class="auth-footer" id="auth-footer">
            New to ZENYTH? <a href="#" data-auth-tab="signup">Create account →</a>
          </div>
        </div>
      </div>
    </div>`;
  }

  /* ════════════════════════════════════════
     SHARED RENDERERS
  ════════════════════════════════════════ */

  /**
   * Render a single product card.
   */
  function renderProductCard(p, delay = 0) {
    const wishlisted = Cart.isWishlisted(p.id);
    return `
      <div class="product-card hover-lift reveal" data-delay="${delay}" data-product-id="${p.id}" role="article" tabindex="0" aria-label="${p.name}">
        <div class="pc-image-wrap">
          <img src="${p.images[0]}" alt="${p.name}" loading="lazy" />
          ${p.badge ? `<div class="pc-badges"><span class="badge badge-${p.badge.type}">${p.badge.text}</span></div>` : ''}
          <button class="pc-wish-btn ${wishlisted ? 'active' : ''}" data-wish-id="${p.id}"
                  aria-label="${wishlisted ? 'Remove from' : 'Add to'} wishlist">
            <i class="fa-${wishlisted ? 'solid' : 'regular'} fa-heart"></i>
          </button>
          <div class="pc-quick-add">
            <button class="btn btn-primary" data-quick-add="${p.id}">
              <i class="fa-solid fa-bag-shopping"></i> Add to Cart
            </button>
          </div>
        </div>
        <div class="pc-body">
          <div class="pc-brand">${p.brand}</div>
          <div class="pc-name">${p.name}</div>
          <div class="pc-rating">
            <div class="pc-stars" aria-label="${p.rating} stars">
              ${renderStars(p.rating)}
            </div>
            <span class="pc-rating-count">(${p.ratingCount >= 1000 ? (p.ratingCount/1000).toFixed(1)+'k' : p.ratingCount})</span>
          </div>
          <div class="pc-price-row">
            <span class="pc-price">${formatPrice(p.price)}</span>
            ${p.originalPrice ? `<span class="pc-original">${formatPrice(p.originalPrice)}</span>` : ''}
            ${p.discount ? `<span class="pc-discount">${p.discount}% off</span>` : ''}
          </div>
          <div class="pc-delivery">
            ${p.freeDelivery ? '<strong>Free</strong> delivery' : `₹99 delivery`}
            · ${p.deliveryDays}d
          </div>
        </div>
      </div>`;
  }

  /** Render a cart item row */
  function renderCartItem(item) {
    const variantStr = Object.entries(item.variant || {})
      .map(([k,v]) => `${k}: ${v}`).join(', ');
    return `
      <div class="cart-item" data-cart-item="${item.id}">
        <div class="ci-image">
          <img src="${item.image}" alt="${item.name}" loading="lazy" />
        </div>
        <div class="ci-info">
          <div class="ci-brand">${item.brand}</div>
          <div class="ci-name">${item.name}</div>
          ${variantStr ? `<div class="ci-meta">${variantStr}</div>` : ''}
          <div class="ci-bottom">
            <div class="ci-price">${formatPrice(item.price * item.qty)}</div>
            <div class="ci-actions">
              <div class="qty-selector">
                <button class="qty-btn ci-qty-dec" data-ci-id="${item.id}" aria-label="Decrease quantity">−</button>
                <input class="qty-value" value="${item.qty}" readonly aria-label="Quantity" />
                <button class="qty-btn ci-qty-inc" data-ci-id="${item.id}" aria-label="Increase quantity">+</button>
              </div>
              <button class="ci-remove" data-ci-remove="${item.id}" aria-label="Remove item">
                <i class="fa-solid fa-trash-can"></i> Remove
              </button>
            </div>
          </div>
        </div>
      </div>`;
  }

  /** Render reviews */
  function _renderReviews(p) {
    const mockReviews = [
      { name: 'Arjun K.',   rating: 5, date: '2 days ago',  text: 'Absolutely love this product! Exceeded all my expectations. Build quality is superb and performance is top-notch.' },
      { name: 'Sneha M.',   rating: 4, date: '1 week ago',  text: 'Really good value for money. Works exactly as described. Delivery was fast too. Would definitely recommend.' },
      { name: 'Rahul T.',   rating: 5, date: '2 weeks ago', text: 'Best purchase I\'ve made this year. The quality is incredible and it arrived well-packaged. 10/10 would buy again.' },
      { name: 'Priya L.',   rating: 4, date: '3 weeks ago', text: 'Great product overall. Minor setup took some time but once done, it\'s been perfect. Very happy with this.' },
    ];
    return `
      <div style="display:flex;gap:32px;flex-wrap:wrap">
        <!-- Rating summary -->
        <div style="flex-shrink:0;min-width:180px">
          <div style="font-size:4rem;font-weight:800;font-family:var(--font-display);color:#FBBF24;line-height:1">${p.rating}</div>
          <div class="stars-display" style="font-size:1.2rem">${renderStars(p.rating)}</div>
          <div style="font-size:0.82rem;color:var(--text-3);margin-top:6px">${p.ratingCount.toLocaleString('en-IN')} ratings</div>
        </div>
        <!-- Reviews list -->
        <div style="flex:1;display:flex;flex-direction:column;gap:20px">
          ${mockReviews.map(r => `
            <div style="padding:20px;background:var(--surface-2);border-radius:var(--radius-md)">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
                <div style="width:32px;height:32px;border-radius:50%;background:var(--violet);display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:700;color:white">${r.name.charAt(0)}</div>
                <strong style="font-size:0.875rem">${r.name}</strong>
                <div class="stars-display" style="font-size:0.8rem">${renderStars(r.rating)}</div>
                <span style="font-size:0.75rem;color:var(--text-3);margin-left:auto">${r.date}</span>
              </div>
              <p style="font-size:0.875rem;color:var(--text-2);line-height:1.6">${r.text}</p>
            </div>`).join('')}
        </div>
      </div>`;
  }

  /** Render specs table */
  function _renderSpecs(p) {
    const specs = [
      ['Brand', p.brand],
      ['Category', CATEGORIES.find(c=>c.id===p.category)?.label || p.category],
      ['Rating', `${p.rating} / 5`],
      ['In Stock', p.inStock ? 'Yes' : 'No'],
      ['Free Delivery', p.freeDelivery ? 'Yes' : 'No'],
      ['Delivery Time', `${p.deliveryDays} day(s)`],
      ...(p.variants?.color ? [['Available Colors', p.variants.color.join(', ')]] : []),
      ...(p.variants?.size  ? [['Available Sizes',  p.variants.size.join(', ')]]  : []),
    ];
    return `
      <table style="width:100%;border-collapse:collapse">
        ${specs.map((row, i) => `
          <tr style="background:${i%2===0?'var(--surface-2)':'transparent'}">
            <td style="padding:12px 16px;font-size:0.85rem;font-weight:600;color:var(--text-3);width:200px">${row[0]}</td>
            <td style="padding:12px 16px;font-size:0.875rem;color:var(--text-1)">${row[1]}</td>
          </tr>`).join('')}
      </table>`;
  }

  /* ── Color mapping ── */
  function _colorMap(name) {
    const map = {
      'black':'#1a1a1a', 'midnight black':'#1a1a1a', 'core black':'#1a1a1a',
      'white':'#f5f5f5', 'pearl white':'#f5f5f5', 'arctic white':'#f5f5f5',
      'blue':'#1e40af', 'ocean blue':'#1e3a8a', 'deep blue':'#1e3a8a',
      'red':'#dc2626', 'product red':'#dc2626', 'burgundy':'#881337',
      'green':'#16a34a', 'sage green':'#4ade80', 'forest green':'#15803d',
      'gold':'#ca8a04', 'rose gold':'#fb7185', 'tan brown':'#92400e',
      'silver':'#94a3b8', 'space gray':'#374151', 'titanium gray':'#4b5563',
      'purple':'#7c3aed', 'lavender':'#a78bfa', 'deep purple':'#4c1d95',
    };
    return map[name.toLowerCase()] || '#888';
  }

  /* ════════════════════════════════════════
     PAGE EVENT HANDLERS
  ════════════════════════════════════════ */
  function _initPageEvents(page, params) {
    // All [data-page] links
    document.querySelectorAll('[data-page]').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault();
        const pg  = el.dataset.page;
        const cat = el.dataset.cat;
        const srch = el.dataset.search;
        navigate(pg, cat ? { category: cat } : srch ? { search: srch } : {});
      });
    });

    // All product cards — navigate to detail on click
    document.querySelectorAll('.product-card').forEach(card => {
      card.addEventListener('click', e => {
        if (e.target.closest('.pc-wish-btn') || e.target.closest('[data-quick-add]')) return;
        const id = card.dataset.productId;
        if (id) navigate('detail', { productId: id });
      });
      card.addEventListener('keydown', e => {
        if (e.key === 'Enter') card.click();
      });
    });

    // Wishlist buttons on cards
    document.querySelectorAll('[data-wish-id]').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = btn.dataset.wishId;
        const isNow = Cart.toggleWishlist(id);
        btn.classList.toggle('active', isNow);
        btn.querySelector('i').className = `fa-${isNow ? 'solid' : 'regular'} fa-heart`;
        btn.style.color = isNow ? '#EF4444' : '';
        Toast.show(
          isNow ? 'Added to Wishlist ❤️' : 'Removed from Wishlist',
          '', isNow ? 'info' : 'warning', 2000
        );
      });
    });

    // Quick Add to Cart buttons on cards
    document.querySelectorAll('[data-quick-add]').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = btn.dataset.quickAdd;
        const product = getProductById(id);
        if (product) {
          Cart.addItem(product, 1);
          Toast.show('Added to Cart! 🛍️', product.name.slice(0, 40) + '…', 'success');
        }
      });
    });

    // CS items (category strip)
    document.querySelectorAll('.cs-item').forEach(el => {
      el.addEventListener('click', () => {
        const cat = el.dataset.cat;
        navigate('products', { category: cat });
      });
    });

    // Promo banners
    document.querySelectorAll('.promo-banner').forEach(el => {
      el.addEventListener('click', () => {
        const cat = el.dataset.cat;
        if (cat) navigate('products', { category: cat });
      });
    });

    // Section "see all" links
    document.querySelectorAll('.sh-see-all').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault();
        const cat = el.dataset.cat || 'all';
        navigate('products', { category: cat });
      });
    });

    if (page === 'products') _initProductPageEvents(params);
    if (page === 'detail')   _initDetailPageEvents(params);
    if (page === 'cart')     _initCartEvents();
    if (page === 'checkout') _initCheckoutEvents();
    if (page === 'login')    _initAuthEvents();
  }

  /* ── Home page specific ── */
  function _initHomeEvents() {
    // Hero search
    const btn      = document.getElementById('hero-search-btn');
    const input    = document.getElementById('hero-search-input');
    const catSel   = document.getElementById('hero-search-cat');

    const doSearch = () => {
      const q   = input?.value.trim();
      const cat = catSel?.value;
      if (q) navigate('products', { search: q });
      else if (cat && cat !== 'all') navigate('products', { category: cat });
      else Search.open();
    };

    btn?.addEventListener('click', doSearch);
    input?.addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });
    input?.addEventListener('focus', () => { if (!input.value) Search.open(); });

    // Flash sale countdown
    const saleEnd = new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString();
    Countdown.start(saleEnd, '#home-countdown');

    // Flash sale button
    document.querySelectorAll('[data-page="products"]').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault();
        navigate('products', { category: el.dataset.cat || 'all' });
      });
    });
  }

  /* ── Products page ── */
  function _initProductPageEvents(params) {
    const grid = document.getElementById('products-grid');
    let currentList = params.search
      ? sortProducts(searchProducts(params.search), params.sort || 'popular')
      : getProductsByCategory(params.category || 'all', params.sort || 'popular');

    // Sort buttons
    document.querySelectorAll('.sort-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const sorted = sortProducts(currentList, btn.dataset.sort);
        _renderProductGrid(grid, sorted);
      });
    });

    // View toggle
    document.querySelectorAll('.view-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        grid?.classList.toggle('list-view', btn.dataset.view === 'list');
      });
    });

    // Category radio filter
    document.querySelectorAll('input[name="filter-cat"]').forEach(radio => {
      radio.addEventListener('change', () => {
        const cat = radio.value;
        navigate('products', { category: cat });
      });
    });

    // Price range
    const priceRange = document.getElementById('price-range');
    const priceLabel = document.getElementById('price-range-val');
    priceRange?.addEventListener('input', () => {
      const max = parseInt(priceRange.value);
      if (priceLabel) priceLabel.textContent = `₹${max.toLocaleString('en-IN')}`;
      const filtered = currentList.filter(p => p.price <= max);
      _renderProductGrid(grid, filtered);
      _updateCount(filtered.length);
    });

    // Star filter
    document.querySelectorAll('.star-filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.star-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const min = parseFloat(btn.dataset.minRating);
        const filtered = currentList.filter(p => p.rating >= min);
        _renderProductGrid(grid, filtered);
        _updateCount(filtered.length);
      });
    });

    // Clear filters
    document.getElementById('clear-filters-btn')?.addEventListener('click', () => {
      navigate('products', { category: params.category || 'all' });
    });

    // Mobile filter toggle
    document.getElementById('filter-toggle-btn')?.addEventListener('click', () => {
      document.getElementById('filter-sidebar')?.classList.toggle('mobile-open');
    });

    // Filter group collapse
    document.querySelectorAll('.filter-group-title').forEach(title => {
      title.addEventListener('click', () => {
        title.closest('.filter-group')?.classList.toggle('collapsed');
      });
    });
  }

  function _renderProductGrid(grid, list) {
    if (!grid) return;
    if (!list.length) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
        <div class="es-icon">🔍</div>
        <h3 class="es-title">No products found</h3>
        <p class="es-desc">Try adjusting your filters.</p>
      </div>`;
      return;
    }
    grid.innerHTML = list.map((p, i) => renderProductCard(p, i * 50)).join('');
    _initPageEvents('products-partial', {});
    Reveal.observe();
  }

  function _updateCount(n) {
    const el = document.getElementById('results-count');
    if (el) el.textContent = n;
  }

  /* ── Detail page ── */
  function _initDetailPageEvents(params) {
    const p = getProductById(params.productId);
    if (!p) return;

    // Thumbnails
    document.querySelectorAll('.pd-thumb').forEach(thumb => {
      thumb.addEventListener('click', () => {
        document.querySelectorAll('.pd-thumb').forEach(t => t.classList.remove('active'));
        thumb.classList.add('active');
        const mainImg = document.getElementById('pd-main-img-el');
        if (mainImg) mainImg.src = thumb.dataset.img;
      });
    });

    // Quantity selector
    let qty = 1;
    const qtyInput = document.getElementById('qty-value');
    document.getElementById('qty-inc')?.addEventListener('click', () => {
      if (qty < 10) { qty++; if (qtyInput) qtyInput.value = qty; }
    });
    document.getElementById('qty-dec')?.addEventListener('click', () => {
      if (qty > 1) { qty--; if (qtyInput) qtyInput.value = qty; }
    });

    // Variant selectors
    document.querySelectorAll('.pv-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const key = btn.dataset.variantKey;
        document.querySelectorAll(`.pv-btn[data-variant-key="${key}"]`).forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
    document.querySelectorAll('.pv-color').forEach(swatch => {
      swatch.addEventListener('click', () => {
        const key = swatch.dataset.variantKey;
        document.querySelectorAll(`.pv-color[data-variant-key="${key}"]`).forEach(s => s.classList.remove('active'));
        swatch.classList.add('active');
      });
    });

    // Get selected variant
    function getVariant() {
      const v = {};
      document.querySelectorAll('.pv-btn.active, .pv-color.active').forEach(el => {
        v[el.dataset.variantKey] = el.dataset.variantVal;
      });
      return v;
    }

    // Add to Cart
    document.getElementById('pd-add-cart')?.addEventListener('click', () => {
      const added = Cart.addItem(p, qty, getVariant());
      if (added) Toast.show('Added to Cart! 🛍️', p.name.slice(0,40)+'…', 'success');
    });

    // Buy Now
    document.getElementById('pd-buy-now')?.addEventListener('click', () => {
      Cart.addItem(p, qty, getVariant());
      navigate('checkout');
    });

    // Wishlist
    document.getElementById('pd-wishlist')?.addEventListener('click', () => {
      const isNow = Cart.toggleWishlist(p.id);
      const btn = document.getElementById('pd-wishlist');
      const icon = btn?.querySelector('i');
      if (btn) btn.style.color = isNow ? '#EF4444' : '';
      if (icon) icon.className = `fa-${isNow?'solid':'regular'} fa-heart`;
      Toast.show(isNow ? 'Wishlisted ❤️' : 'Removed from wishlist', '', isNow ? 'info' : 'warning', 2000);
    });

    // Tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => { b.classList.remove('active'); b.setAttribute('aria-selected','false'); });
        document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');
        const panel = document.getElementById(`tab-${btn.dataset.tab}`);
        if (panel) panel.classList.add('active');
      });
    });
  }

  /* ── Cart page ── */
  function _initCartEvents() {
    // Qty buttons
    document.querySelectorAll('.ci-qty-dec, .ci-qty-inc').forEach(btn => {
      btn.addEventListener('click', () => {
        const id   = btn.dataset.ciId || btn.dataset.ciId;
        const isInc = btn.classList.contains('ci-qty-inc');
        const { items } = Cart.getCartData();
        const item = items.find(i => i.id === id);
        if (!item) return;
        Cart.updateQty(id, item.variant, isInc ? item.qty + 1 : item.qty - 1);
        navigate('cart'); // re-render
      });
    });

    // Remove buttons
    document.querySelectorAll('[data-ci-remove]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.ciRemove;
        const { items } = Cart.getCartData();
        const item = items.find(i => i.id === id);
        Cart.removeItem(id, item?.variant || {});
        Toast.show('Item removed', '', 'warning', 2000);
        navigate('cart');
      });
    });

    // Coupon
    document.getElementById('coupon-apply-btn')?.addEventListener('click', () => {
      const code  = document.getElementById('coupon-input')?.value;
      const msgEl = document.getElementById('coupon-msg');
      if (!code) return;
      const result = Cart.applyCoupon(code);
      if (msgEl) {
        msgEl.textContent = result.message;
        msgEl.style.color = result.success ? '#34D399' : '#EF4444';
      }
      if (result.success) {
        Toast.show('Coupon Applied! 🎉', result.coupon.label, 'success');
      }
    });

    // Checkout button
    document.getElementById('checkout-btn')?.addEventListener('click', () => {
      navigate('checkout');
    });
  }

  /* ── Checkout page ── */
  function _initCheckoutEvents() {
    // Payment method selection
    document.querySelectorAll('.pm-option').forEach(opt => {
      opt.addEventListener('click', () => {
        document.querySelectorAll('.pm-option').forEach(o => {
          o.classList.remove('selected');
          o.setAttribute('aria-checked','false');
        });
        opt.classList.add('selected');
        opt.setAttribute('aria-checked','true');
        const cardFields = document.getElementById('card-fields');
        if (cardFields) cardFields.style.display = opt.dataset.pm === 'card' ? 'block' : 'none';
      });
    });

    // Place order
    document.getElementById('place-order-btn')?.addEventListener('click', () => {
      const required = ['ch-fname','ch-lname','ch-email','ch-phone','ch-addr','ch-city','ch-pin'];
      let valid = true;
      required.forEach(id => {
        const el = document.getElementById(id);
        if (!el?.value.trim()) { el?.classList.add('error'); valid = false; }
        else el?.classList.remove('error');
      });
      if (!valid) {
        Toast.show('Missing Details', 'Please fill in all required fields.', 'error');
        return;
      }
      // Simulate order placement
      const btn = document.getElementById('place-order-btn');
      if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Placing Order…'; }
      setTimeout(() => {
        Cart.clear();
        const app = document.getElementById('app');
        if (app) app.innerHTML = `
          <div style="text-align:center;padding:100px 20px">
            <div style="font-size:4rem;margin-bottom:24px">🎉</div>
            <h1 class="font-display" style="font-size:2rem;font-weight:800;margin-bottom:12px">Order Placed Successfully!</h1>
            <p style="color:var(--text-2);max-width:440px;margin:0 auto 32px">
              Thank you for shopping with ZENYTH. Your order will arrive in 2–5 business days.
              A confirmation has been sent to your email.
            </p>
            <div style="display:inline-flex;align-items:center;gap:10px;padding:16px 24px;background:var(--surface-1);border:1px solid var(--border);border-radius:var(--radius-md);font-family:var(--font-mono);font-size:0.9rem;margin-bottom:32px">
              Order ID: <strong style="color:var(--violet-light)">ZYT-${Math.random().toString(36).substr(2,8).toUpperCase()}</strong>
            </div><br/>
            <button class="btn btn-primary btn-lg" data-page="home">Continue Shopping</button>
          </div>`;
        _initPageEvents('order-success', {});
      }, 1800);
    });
  }

  /* ── Auth page ── */
  function _initAuthEvents() {
    // Tab switching
    document.querySelectorAll('[data-auth-tab]').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault();
        const tab = el.dataset.authTab;
        document.querySelectorAll('.auth-tab').forEach(t => {
          t.classList.toggle('active', t.dataset.authTab === tab);
          t.setAttribute('aria-selected', String(t.dataset.authTab === tab));
        });
        const lf = document.getElementById('login-form');
        const sf = document.getElementById('signup-form');
        const af = document.getElementById('auth-footer');
        if (tab === 'login') {
          if (lf) lf.style.display = ''; if (sf) sf.style.display = 'none';
          if (af) af.innerHTML = `New to ZENYTH? <a href="#" data-auth-tab="signup">Create account →</a>`;
        } else {
          if (lf) lf.style.display = 'none'; if (sf) sf.style.display = '';
          if (af) af.innerHTML = `Already have an account? <a href="#" data-auth-tab="login">Log in →</a>`;
        }
        _initAuthEvents(); // rebind after DOM update
      });
    });

    // Password toggle
    document.getElementById('toggle-pw')?.addEventListener('click', () => {
      const pw = document.getElementById('login-password');
      if (pw) pw.type = pw.type === 'password' ? 'text' : 'password';
    });

    // Login form
    document.getElementById('login-form')?.addEventListener('submit', e => {
      e.preventDefault();
      const email = document.getElementById('login-email')?.value.trim();
      const pw    = document.getElementById('login-password')?.value;
      let ok = true;

      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        document.getElementById('login-email-err').textContent = 'Enter a valid email.';
        document.getElementById('login-email')?.classList.add('error');
        ok = false;
      } else {
        document.getElementById('login-email-err').textContent = '';
        document.getElementById('login-email')?.classList.remove('error');
      }
      if (!pw || pw.length < 6) {
        document.getElementById('login-pw-err').textContent = 'Password must be at least 6 characters.';
        document.getElementById('login-password')?.classList.add('error');
        ok = false;
      } else {
        document.getElementById('login-pw-err').textContent = '';
        document.getElementById('login-password')?.classList.remove('error');
      }
      if (!ok) return;

      const btn = document.getElementById('login-submit-btn');
      if (btn) { btn.disabled = true; btn.textContent = 'Logging in…'; }
      setTimeout(() => {
        Toast.show('Welcome back! 👋', `Logged in as ${email}`, 'success');
        navigate('home');
      }, 1200);
    });

    // Signup form
    document.getElementById('signup-form')?.addEventListener('submit', e => {
      e.preventDefault();
      const fname = document.getElementById('su-fname')?.value.trim();
      const email = document.getElementById('su-email')?.value.trim();
      const pw    = document.getElementById('su-password')?.value;
      let ok = true;

      if (!fname || fname.length < 2) {
        document.getElementById('su-fname-err').textContent = 'Enter your first name.';
        ok = false;
      } else { document.getElementById('su-fname-err').textContent = ''; }
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        document.getElementById('su-email-err').textContent = 'Enter a valid email.';
        ok = false;
      } else { document.getElementById('su-email-err').textContent = ''; }
      if (!pw || pw.length < 8) {
        document.getElementById('su-pw-err').textContent = 'Password must be at least 8 characters.';
        ok = false;
      } else { document.getElementById('su-pw-err').textContent = ''; }

      if (!ok) return;
      const btn = document.getElementById('signup-submit-btn');
      if (btn) { btn.disabled = true; btn.textContent = 'Creating account…'; }
      setTimeout(() => {
        Toast.show('Account Created! 🎉', `Welcome to ZENYTH, ${fname}!`, 'success');
        navigate('home');
      }, 1400);
    });

    // Social buttons
    document.getElementById('google-login')?.addEventListener('click', () => {
      Toast.show('Google Sign-In', 'OAuth integration coming soon!', 'info');
    });
    document.getElementById('apple-login')?.addEventListener('click', () => {
      Toast.show('Apple Sign-In', 'OAuth integration coming soon!', 'info');
    });
  }

  /* ════════════════════════════════════════
     BOOT
  ════════════════════════════════════════ */
  function init() {
    Preloader.run();
    setTimeout(() => {
      Cart.init();
      initUI();
      Search.init();
      navigate('home');
    }, 1800);
  }

  return { navigate, init };
})();

window.App = App;

/* ─── Boot the app ─────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => App.init());
