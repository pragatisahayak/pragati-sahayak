/* ════════════════════════════════════════════════════════
   ZENYTH — ui.js
   Global UI: Toast · Theme · Scroll · Navbar · Countdown
              Reveal animations · Back-to-top · Preloader
   ════════════════════════════════════════════════════════ */

'use strict';

/* ════════════════ TOAST SYSTEM ════════════════ */
const Toast = (() => {
  const container = document.getElementById('toast-container');
  let queue = [];

  const ICONS = {
    success: 'fa-circle-check',
    error:   'fa-circle-xmark',
    info:    'fa-circle-info',
    warning: 'fa-triangle-exclamation',
  };

  /**
   * Show a toast notification.
   * @param {string} title    - Bold title
   * @param {string} message  - Subtitle message
   * @param {string} type     - success | error | info | warning
   * @param {number} duration - ms before auto-dismiss (default 3500)
   */
  function show(title, message = '', type = 'success', duration = 3500) {
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
      <div class="toast-icon">
        <i class="fa-solid ${ICONS[type] || ICONS.info}"></i>
      </div>
      <div class="toast-body">
        <div class="toast-title">${_esc(title)}</div>
        ${message ? `<div class="toast-msg">${_esc(message)}</div>` : ''}
      </div>
      <button class="toast-close" aria-label="Dismiss"><i class="fa-solid fa-xmark"></i></button>`;

    container.appendChild(toast);

    // Close button
    toast.querySelector('.toast-close').addEventListener('click', () => dismiss(toast));

    // Auto-dismiss
    const timer = setTimeout(() => dismiss(toast), duration);
    toast._timer = timer;

    // Pause on hover
    toast.addEventListener('mouseenter', () => clearTimeout(toast._timer));
    toast.addEventListener('mouseleave', () => {
      toast._timer = setTimeout(() => dismiss(toast), 1500);
    });

    return toast;
  }

  function dismiss(toast) {
    if (!toast || toast._removing) return;
    toast._removing = true;
    clearTimeout(toast._timer);
    toast.classList.add('removing');
    toast.addEventListener('animationend', () => toast.remove(), { once: true });
  }

  function _esc(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  return { show };
})();

/* ════════════════ THEME ════════════════ */
const Theme = (() => {
  const KEY = 'zenyth_theme';
  const html = document.documentElement;
  const btn  = document.getElementById('theme-toggle-btn');
  const icon = document.getElementById('theme-icon');

  function apply(t) {
    html.setAttribute('data-theme', t);
    if (icon) icon.className = t === 'dark' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
    localStorage.setItem(KEY, t);
  }

  function init() {
    const saved = localStorage.getItem(KEY) ||
      (window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');
    apply(saved);

    btn?.addEventListener('click', () => {
      apply(html.dataset.theme === 'dark' ? 'light' : 'dark');
    });
  }

  return { init };
})();

/* ════════════════ NAVBAR ════════════════ */
const Navbar = (() => {
  const header    = document.getElementById('site-header');
  const hamburger = document.getElementById('hamburger-btn');
  const mobileNav = document.getElementById('mobile-nav');

  function init() {
    /* Scroll class */
    window.addEventListener('scroll', () => {
      if (!header) return;
      header.style.boxShadow = window.scrollY > 10 ? '0 4px 24px rgba(0,0,0,0.3)' : '';
    }, { passive: true });

    /* Hamburger */
    hamburger?.addEventListener('click', () => {
      const open = hamburger.classList.toggle('open');
      mobileNav?.classList.toggle('open', open);
      hamburger.setAttribute('aria-expanded', String(open));
      mobileNav?.setAttribute('aria-hidden', String(!open));
      document.body.style.overflow = open ? 'hidden' : '';
    });

    /* Close mobile nav on link click */
    mobileNav?.querySelectorAll('.mn-link').forEach(link => {
      link.addEventListener('click', () => {
        hamburger?.classList.remove('open');
        mobileNav.classList.remove('open');
        hamburger?.setAttribute('aria-expanded', 'false');
        mobileNav.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
      });
    });

    /* Cart nav button */
    document.getElementById('cart-nav-btn')?.addEventListener('click', () => {
      window.App?.navigate('cart');
    });

    /* User nav button */
    document.getElementById('user-nav-btn')?.addEventListener('click', () => {
      window.App?.navigate('login');
    });

    /* Wishlist nav button */
    document.getElementById('wishlist-btn')?.addEventListener('click', () => {
      Toast.show('Wishlist', 'Your wishlist feature is coming soon!', 'info');
    });

    /* Footer links */
    document.querySelectorAll('[data-page]').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault();
        const page = el.dataset.page;
        const cat  = el.dataset.cat;
        window.App?.navigate(page, cat ? { category: cat } : {});
      });
    });

    /* Nav logo */
    document.getElementById('nav-logo-link')?.addEventListener('click', e => {
      e.preventDefault();
      window.App?.navigate('home');
    });

    document.querySelectorAll('.footer-logo').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault();
        window.App?.navigate('home');
      });
    });
  }

  return { init };
})();

/* ════════════════ SCROLL PROGRESS ════════════════ */
const ScrollProgress = (() => {
  const bar = document.getElementById('scroll-bar');

  function init() {
    window.addEventListener('scroll', () => {
      if (!bar) return;
      const pct = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      bar.style.width = Math.min(pct, 100) + '%';
    }, { passive: true });
  }

  return { init };
})();

/* ════════════════ BACK TO TOP ════════════════ */
const BackToTop = (() => {
  const btn = document.getElementById('back-top');

  function init() {
    window.addEventListener('scroll', () => {
      btn?.classList.toggle('visible', window.scrollY > 400);
    }, { passive: true });

    btn?.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  return { init };
})();

/* ════════════════ REVEAL ANIMATIONS ════════════════ */
const Reveal = (() => {
  let observer;

  function init() {
    observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const delay = parseInt(entry.target.dataset.delay || 0);
          setTimeout(() => entry.target.classList.add('visible'), delay);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  }

  function observe() {
    document.querySelectorAll('.reveal, .reveal-left, .reveal-right').forEach(el => {
      if (!el.classList.contains('visible')) observer?.observe(el);
    });
  }

  return { init, observe };
})();

/* ════════════════ COUNTDOWN TIMER ════════════════ */
const Countdown = (() => {
  let interval;

  /**
   * Render a countdown to a target date string (ISO).
   * Injects into elements with data-countdown="hours|minutes|seconds|days"
   */
  function start(targetDateISO, containerSelector) {
    const container = document.querySelector(containerSelector);
    if (!container) return;

    clearInterval(interval);

    function tick() {
      const now    = new Date();
      const target = new Date(targetDateISO);
      const diff   = Math.max(0, target - now);

      const hrs  = Math.floor(diff / 3600000);
      const mins = Math.floor((diff % 3600000) / 60000);
      const secs = Math.floor((diff % 60000) / 1000);

      const hEl = container.querySelector('[data-cd="hours"]');
      const mEl = container.querySelector('[data-cd="minutes"]');
      const sEl = container.querySelector('[data-cd="seconds"]');

      if (hEl) hEl.textContent  = String(hrs).padStart(2, '0');
      if (mEl) mEl.textContent  = String(mins).padStart(2, '0');
      if (sEl) sEl.textContent  = String(secs).padStart(2, '0');

      if (diff <= 0) clearInterval(interval);
    }

    tick();
    interval = setInterval(tick, 1000);
  }

  function stop() { clearInterval(interval); }

  return { start, stop };
})();

/* ════════════════ PRELOADER ════════════════ */
const Preloader = (() => {
  const el     = document.getElementById('preloader');
  const fill   = document.getElementById('pre-fill');
  const status = document.getElementById('pre-status');

  const messages = [
    'Loading catalogue…',
    'Syncing inventory…',
    'Personalising experience…',
    'Almost ready…',
  ];

  function run() {
    if (!el) return;
    let pct = 0;
    let msgIdx = 0;

    const interval = setInterval(() => {
      pct += Math.floor(Math.random() * 18) + 6;
      pct  = Math.min(pct, 100);
      if (fill)  fill.style.width = pct + '%';
      if (status && pct > msgIdx * 28 && messages[msgIdx]) {
        status.textContent = messages[msgIdx++] || '';
      }
      if (pct >= 100) {
        clearInterval(interval);
        setTimeout(() => el.classList.add('out'), 300);
      }
    }, 80);
  }

  return { run };
})();

/* ════════════════ FOOTER YEAR ════════════════ */
function initFooterYear() {
  const el = document.getElementById('footer-year');
  if (el) el.textContent = new Date().getFullYear();
}

/* ════════════════ INIT ALL ════════════════ */
function initUI() {
  Theme.init();
  Navbar.init();
  ScrollProgress.init();
  BackToTop.init();
  Reveal.init();
  initFooterYear();

  /* Newsletter form */
  document.querySelector('.fn-btn')?.addEventListener('click', () => {
    const input = document.querySelector('.fn-input');
    if (!input) return;
    const email = input.value.trim();
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!re.test(email)) {
      Toast.show('Invalid Email', 'Please enter a valid email address.', 'error');
      return;
    }
    input.value = '';
    Toast.show('Subscribed! 🎉', 'You\'re now on the ZENYTH insider list.', 'success');
  });
}

/* Expose globally */
window.Toast     = Toast;
window.Countdown = Countdown;
window.Reveal    = Reveal;
window.initUI    = initUI;
window.Preloader = Preloader;
