/* ════════════════════════════════════════════════════════
   ZENYTH — search.js
   Live search: overlay, suggestions, debounce, keyboard nav
   ════════════════════════════════════════════════════════ */

'use strict';

const Search = (() => {

  const DEBOUNCE_MS    = 220;
  const MAX_SUGGESTIONS = 8;

  let debounceTimer = null;
  let activeSuggIndex = -1;
  let currentSuggestions = [];

  /* ── Elements ── */
  const overlay     = document.getElementById('search-overlay');
  const input       = document.getElementById('overlay-search-input');
  const suggBox     = document.getElementById('so-suggestions');
  const trendingBox = document.getElementById('so-trending');
  const tagsBox     = document.getElementById('so-tags');
  const clearBtn    = document.getElementById('so-clear-btn');
  const searchTrigger = document.getElementById('search-trigger-btn');

  /* ── Open / Close ── */
  function open() {
    overlay.classList.add('open');
    overlay.setAttribute('aria-hidden', 'false');
    setTimeout(() => input && input.focus(), 50);
    document.body.style.overflow = 'hidden';
    _renderTrending();
  }

  function close() {
    overlay.classList.remove('open');
    overlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (input) input.value = '';
    _clearSuggestions();
  }

  /* ── Trending tags ── */
  function _renderTrending() {
    if (!tagsBox) return;
    tagsBox.innerHTML = TRENDING_SEARCHES
      .slice(0, 10)
      .map(t => `<button class="chip" data-search="${t}">${t}</button>`)
      .join('');

    tagsBox.querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', () => {
        input.value = chip.dataset.search;
        _runSearch(chip.dataset.search);
      });
    });
  }

  /* ── Live search ── */
  function _runSearch(query) {
    activeSuggIndex = -1;
    if (!query || query.trim().length < 2) {
      _clearSuggestions();
      trendingBox.style.display = '';
      return;
    }

    trendingBox.style.display = 'none';
    const results = searchProducts(query).slice(0, MAX_SUGGESTIONS);
    currentSuggestions = results;
    _renderSuggestions(query, results);
  }

  function _renderSuggestions(query, results) {
    if (!suggBox) return;

    if (results.length === 0) {
      suggBox.innerHTML = `
        <div class="so-suggestion-item" style="justify-content:center;color:var(--text-3)">
          <i class="fa-solid fa-face-meh"></i>
          No results for "<strong style="color:var(--text-1)">${_esc(query)}</strong>"
        </div>`;
      suggBox.classList.add('visible');
      return;
    }

    const highlighted = query.trim();
    suggBox.innerHTML = results.map((p, i) => {
      const name = _highlight(p.name.slice(0, 60) + (p.name.length > 60 ? '…' : ''), highlighted);
      return `
        <div class="so-suggestion-item" role="option" tabindex="-1"
             data-index="${i}" data-product-id="${p.id}"
             aria-label="${_esc(p.name)}">
          <i class="fa-solid fa-magnifying-glass"></i>
          <div>
            <div>${name}</div>
            <div style="font-size:0.75rem;color:var(--text-3);margin-top:2px">
              ${_esc(p.brand)} · ${p.category}
            </div>
          </div>
          <div style="margin-left:auto;font-size:0.82rem;font-weight:700;color:var(--text-1)">
            ${formatPrice(p.price)}
          </div>
        </div>`;
    }).join('') + `
      <div class="so-suggestion-item" role="option" tabindex="-1"
           data-search-all="${_esc(query)}"
           style="justify-content:center;color:var(--violet-light);font-weight:600">
        <i class="fa-solid fa-arrow-right"></i>
        See all results for "<span class="so-suggestion-match">${_esc(query)}</span>"
      </div>`;

    suggBox.classList.add('visible');

    /* Bind clicks */
    suggBox.querySelectorAll('[data-product-id]').forEach(el => {
      el.addEventListener('click', () => {
        const id = el.dataset.productId;
        close();
        App.navigate('detail', { productId: id });
      });
    });

    suggBox.querySelector('[data-search-all]')?.addEventListener('click', () => {
      const q = suggBox.querySelector('[data-search-all]').dataset.searchAll;
      close();
      App.navigate('products', { search: q });
    });
  }

  function _clearSuggestions() {
    if (suggBox) { suggBox.innerHTML = ''; suggBox.classList.remove('visible'); }
    currentSuggestions = [];
    activeSuggIndex = -1;
    if (trendingBox) trendingBox.style.display = '';
  }

  /* ── Keyboard navigation ── */
  function _handleKeydown(e) {
    const items = suggBox ? [...suggBox.querySelectorAll('.so-suggestion-item')] : [];
    if (!items.length) {
      if (e.key === 'Enter' && input.value.trim()) {
        close();
        App.navigate('products', { search: input.value.trim() });
      }
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      activeSuggIndex = Math.min(activeSuggIndex + 1, items.length - 1);
      _highlightSugg(items);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      activeSuggIndex = Math.max(activeSuggIndex - 1, -1);
      _highlightSugg(items);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (activeSuggIndex >= 0 && items[activeSuggIndex]) {
        items[activeSuggIndex].click();
      } else {
        close();
        App.navigate('products', { search: input.value.trim() });
      }
    } else if (e.key === 'Escape') {
      close();
    }
  }

  function _highlightSugg(items) {
    items.forEach((el, i) => {
      el.style.background = i === activeSuggIndex ? 'var(--surface-2)' : '';
    });
    if (activeSuggIndex >= 0 && currentSuggestions[activeSuggIndex]) {
      input.value = currentSuggestions[activeSuggIndex].name;
    }
  }

  /* ── Helpers ── */
  function _highlight(text, query) {
    if (!query) return _esc(text);
    const re = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')})`, 'gi');
    return _esc(text).replace(re, '<span class="so-suggestion-match">$1</span>');
  }

  function _esc(s) {
    return String(s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  /* ── Init ── */
  function init() {
    /* Search trigger button */
    searchTrigger?.addEventListener('click', open);

    /* Backdrop click */
    overlay?.querySelector('.so-backdrop')?.addEventListener('click', close);

    /* Input events */
    input?.addEventListener('input', e => {
      clearTimeout(debounceTimer);
      const q = e.target.value;
      clearBtn.style.display = q ? 'block' : 'none';
      debounceTimer = setTimeout(() => _runSearch(q), DEBOUNCE_MS);
    });

    input?.addEventListener('keydown', _handleKeydown);

    /* Clear button */
    clearBtn?.addEventListener('click', () => {
      input.value = '';
      clearBtn.style.display = 'none';
      _clearSuggestions();
      input.focus();
    });

    /* Mobile search */
    const mobileInput = document.getElementById('mobile-search-input');
    mobileInput?.addEventListener('keydown', e => {
      if (e.key === 'Enter' && mobileInput.value.trim()) {
        App.navigate('products', { search: mobileInput.value.trim() });
        // close mobile nav
        document.getElementById('hamburger-btn')?.classList.remove('open');
        document.getElementById('mobile-nav')?.classList.remove('open');
        document.body.style.overflow = '';
      }
    });

    /* Mega menu links */
    document.querySelectorAll('.mega-link').forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        const cat = link.dataset.filterCat;
        if (cat) App.navigate('products', { category: cat });
      });
    });
  }

  return { init, open, close };
})();

window.Search = Search;
