/* ════════════════════════════════════════════════════════
   ZENYTH — cart.js
   Cart & Wishlist management with localStorage persistence
   ════════════════════════════════════════════════════════ */

'use strict';

/* ─── Cart State ─────────────────────────────────────── */
const Cart = (() => {

  const CART_KEY     = 'zenyth_cart_v1';
  const WISH_KEY     = 'zenyth_wishlist_v1';
  const DELIVERY_FEE = 99;   // free above threshold
  const FREE_ABOVE   = 499;

  /* Load from localStorage */
  let items     = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
  let wishlist  = JSON.parse(localStorage.getItem(WISH_KEY) || '[]');

  /* ── Persistence ── */
  function save() {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
    _updateBadges();
    _dispatchChange();
  }

  function saveWish() {
    localStorage.setItem(WISH_KEY, JSON.stringify(wishlist));
    _updateWishBadge();
  }

  /* ── Internal helpers ── */
  function _updateBadges() {
    const total = items.reduce((sum, i) => sum + i.qty, 0);
    const badge = document.getElementById('cart-badge');
    if (!badge) return;
    if (total > 0) {
      badge.textContent = total > 99 ? '99+' : total;
      badge.style.display = 'flex';
    } else {
      badge.style.display = 'none';
    }
  }

  function _updateWishBadge() {
    const badge = document.getElementById('wishlist-badge');
    if (!badge) return;
    if (wishlist.length > 0) {
      badge.textContent = wishlist.length;
      badge.style.display = 'flex';
    } else {
      badge.style.display = 'none';
    }
  }

  function _dispatchChange() {
    window.dispatchEvent(new CustomEvent('cart:changed', { detail: getCartData() }));
  }

  function _findItem(productId, variant) {
    return items.find(i =>
      i.id === productId &&
      JSON.stringify(i.variant) === JSON.stringify(variant)
    );
  }

  /* ── Public API ── */

  /**
   * Add a product to the cart.
   * If the same product+variant exists, increment quantity.
   * @param {Object} product  — full product object from data.js
   * @param {number} qty      — quantity to add
   * @param {Object} variant  — e.g. { color: 'Black', size: 'M' }
   */
  function addItem(product, qty = 1, variant = {}) {
    if (!product || !product.inStock) return false;

    const existing = _findItem(product.id, variant);
    if (existing) {
      existing.qty = Math.min(existing.qty + qty, 10); // max 10 per item
    } else {
      items.push({
        id:       product.id,
        name:     product.name,
        brand:    product.brand,
        price:    product.price,
        original: product.originalPrice,
        image:    product.images[0],
        variant,
        qty,
        addedAt:  Date.now(),
      });
    }
    save();
    return true;
  }

  /**
   * Remove an item from the cart entirely.
   */
  function removeItem(productId, variant = {}) {
    items = items.filter(i =>
      !(i.id === productId && JSON.stringify(i.variant) === JSON.stringify(variant))
    );
    save();
  }

  /**
   * Update quantity. Pass 0 to remove.
   */
  function updateQty(productId, variant = {}, newQty) {
    if (newQty <= 0) { removeItem(productId, variant); return; }
    const item = _findItem(productId, variant);
    if (item) { item.qty = Math.min(newQty, 10); save(); }
  }

  /**
   * Clear the entire cart.
   */
  function clear() {
    items = [];
    save();
  }

  /**
   * Get full cart data with totals.
   */
  function getCartData() {
    const subtotal  = items.reduce((sum, i) => sum + i.price * i.qty, 0);
    const savings   = items.reduce((sum, i) => sum + (i.original - i.price) * i.qty, 0);
    const delivery  = subtotal > FREE_ABOVE ? 0 : (items.length > 0 ? DELIVERY_FEE : 0);
    const total     = subtotal + delivery;
    return { items: [...items], subtotal, savings, delivery, total, count: items.reduce((s,i)=>s+i.qty,0) };
  }

  /**
   * Get just the items array.
   */
  function getItems() { return [...items]; }

  /**
   * Check if a product is in the cart.
   */
  function hasItem(productId) { return items.some(i => i.id === productId); }

  /* ── Wishlist ── */

  function toggleWishlist(productId) {
    const idx = wishlist.indexOf(productId);
    if (idx === -1) { wishlist.push(productId); }
    else            { wishlist.splice(idx, 1); }
    saveWish();
    return wishlist.includes(productId);
  }

  function isWishlisted(productId) { return wishlist.includes(productId); }
  function getWishlist()           { return [...wishlist]; }

  /* ── Coupon (simulated) ── */
  const COUPONS = {
    'ZENYTH10':  { type: 'percent', value: 10, label: '10% off' },
    'WELCOME20': { type: 'percent', value: 20, label: '20% off' },
    'FLAT500':   { type: 'flat',    value: 500, label: '₹500 off' },
    'NEWUSER':   { type: 'flat',    value: 200, label: '₹200 off' },
  };

  function applyCoupon(code) {
    const c = COUPONS[code.toUpperCase()];
    if (!c) return { success: false, message: 'Invalid coupon code.' };
    return { success: true, coupon: c, message: `${c.label} applied!` };
  }

  /* ── Init ── */
  function init() {
    _updateBadges();
    _updateWishBadge();
  }

  return {
    addItem, removeItem, updateQty, clear,
    getCartData, getItems, hasItem,
    toggleWishlist, isWishlisted, getWishlist,
    applyCoupon, init,
  };
})();

/* Expose globally */
window.Cart = Cart;
